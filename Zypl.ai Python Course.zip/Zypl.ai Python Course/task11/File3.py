a = int(input("Input A: "))
#a=5
if a % 2 == 0:
    print("Number is even")
else:
    print("Number is odd")
