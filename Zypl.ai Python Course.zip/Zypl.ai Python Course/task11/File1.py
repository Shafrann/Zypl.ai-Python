a = "Салом"
print(a)
b = 'c'
print(b)
