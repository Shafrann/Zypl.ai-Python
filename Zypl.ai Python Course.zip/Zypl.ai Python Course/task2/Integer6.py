a = int(input("Input A: "))
#12
b = a // 10
c = a % 10
print(f"First number is: {b},  Second number is: {c}")



