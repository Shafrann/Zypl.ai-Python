n = int(input("Input seconds: "))
b = n % 60
print("Seconds after last minute: ", b)
