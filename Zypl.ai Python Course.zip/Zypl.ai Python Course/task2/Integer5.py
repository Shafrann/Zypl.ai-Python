a = int(input("Input A: "))
b = int(input("Input B: "))
n = a % b
print("Unoccupied part is: ", n)
