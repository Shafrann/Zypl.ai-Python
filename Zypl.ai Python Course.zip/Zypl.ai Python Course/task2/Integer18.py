a = int(input("Input number: "))
b = a // 1000
c = b % 10
print("Result is: ", c)
