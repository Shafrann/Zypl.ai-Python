a = float(input("Input A: "))
b = float(input("Input B: "))
s = a * b
p = 2 * (a + b)
print(f"Area S is: {s}  and  Perimeter P is: {p}")
