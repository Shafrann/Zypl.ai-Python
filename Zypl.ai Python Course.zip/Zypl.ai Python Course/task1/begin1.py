a = float(input("Input A: "))
p = a * 4
print(f"Perimeter: {p}")
