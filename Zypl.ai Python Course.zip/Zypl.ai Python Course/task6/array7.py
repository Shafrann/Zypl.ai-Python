n = int(input())

res = []
for i in range(n):
    a = int(input())
    res.append(a)

res = res[::-1]
print(res)
