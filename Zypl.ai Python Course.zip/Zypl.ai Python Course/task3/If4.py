a = int(input("Input A: "))
b = int(input("Input B: "))
c = int(input("Input C: "))
k = 0
if a > 0:
    k += 1
if b > 0:
    k += 1
if c > 0:
    k += 1
print("Amount of positives is: ", k)
