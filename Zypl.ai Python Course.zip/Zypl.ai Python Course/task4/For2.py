a = int(input("Input A: "))
b = int(input("Input B: "))
n = 0
for i in range(a, b+1):
    print(i)
    n += 1
print()
print(n)
