a = int(input("Input A: "))
while a > 1:
    a /= 3

if a == 1:
    print("True")
else:
    print("False")
