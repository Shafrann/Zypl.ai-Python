N = int(input())
res = []
for i in range(1, N + 1):
    res.append(2 ** i)
print(res)
